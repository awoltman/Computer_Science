public 24
{
{public static void main(String[]args)

int a;
a=10;
}
}