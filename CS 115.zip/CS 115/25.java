public 25
{
{public static void main(String[]args)

boolean a;
a=false;
}
}