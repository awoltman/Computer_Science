public 26
{
{public static void main(String[]args)

char a;
a=B;
}
}