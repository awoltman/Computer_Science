public 47
{
{public static void main(String[]args)

system.out.println"*       *";
system.out.println"  *   *";
system.out.println"    *";
system.out.println"  *   *";
system.out.println"*       *";

}
}