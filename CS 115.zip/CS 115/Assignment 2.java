public class Assignment2

//number 27
{
	public static void main(String[]args)
	
	{
	int a= 3;
	int b= 5;
	int c= 8;
	System.out.println("the value of int a" + a);
	System.out.println("the value of int b" + b);
	System.out.println("the value of int b" + c)
	}


//number 28
	{
	Sum= a+b;
	average=(double) Sum/2;
	System.out.println("\nTypecast one variable to double,"+ "then perform division")
		System.ou.println("the average of a and b is" + average)
	}
	
/*Number 33
3.3 is not an integer

	Number 34
	the float statement is false, b=a is not a float statement
	
		Number 35
		7.3 is not an integer, the correct way to do that would have been to use double instead of int
		
			Number 36
			the answer that it would give you is infinity
				
				Number 37
				the error occured when they put a space between the - and =, there is no space inbetween in those statements
				
					Number 42
					the reason why this does not work is because when you do double c = a/b but both a and b are integers then the final answer that is going
					give you will also be an integer. to fix this issue you can chang one or both a and b to doubles
						
						Number 43
						this does not do what you wnat it to do becase the syntax is wrong, it is supposed to be += not =+
*/
	//Number 44
	{
		int a= 1;
		int b= 2;
		int c= 3;
		int d= 4;
		int e= 5;
		int f= 6;
		int g= 7;
		int h= 8;
		int i= 9;
		
		System.out.println("a squared" a*a);
		System.out.println("a squared" b*b);
		System.out.println("a squared" c*c);
		System.out.println("a squared" d*d);
		System.out.println("a squared" e*e);
		System.out.println("a squared" f*f);
		System.out.println("a squared" g*g);
		System.out.println("a squared" h*h);
		System.out.println("a squared" i*i);
	}
	
	//Number50
	{
		
		double radius= 3.2;
		Circumference= 2*radius*(Math.PI);
		System.out.println(+ Circumference);
	}
	
	/* Number 52
		This is not a good idea because it hard to read. If you encounter a problem with the program down the road it will make it hard to find
		mistake in the code. It is also harder to change a number "A" to a different number because it will be harder to find.
	
	//Number 57
	{
	Scanner coinScanner = new scanner (System.in);
	int numberOfQuarters= a ,numberOfDimes= b ,numberOfNickles;
	double totalMoney
	
	System.out.println( "Please enter number of Quarters");
	numberOfQuarters= coinScanner.nextInt() ;
	
	System.out.println("Please enter number of Dimes");
	numberOfDimes= coinScanner.nextInt();
	
	System.out.println("Please enter number of Nickles")
	numberOfNickles= coinScanner.nextInt();
	
	totalMoney= (numberOfQuarters*.25+numberOfDimes*.10+numberOfNickles*.05;
	System.out.println("totalMoney in $" +totalMoney);
	}
	
	//Number 58
	
	{
	Scanner math = new Scanner (System.in);
	
	double r;
	
	System.out.println(Please enter the radius of the circle);
	r= math.nextInt();
	
	double area =(Math.PI)*r*r;
	
	double circumference= 2*(Math.PI)*r;
	
	System.out.println("Area of circle" +area);
	
	System.out.println("Circumference of circle"+ circumference);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	