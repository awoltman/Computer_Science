/*
	Number 17
		[]output is Season is summer
	
	Number 18
		[]output is letter 2
		
	Number 31
		[]it must be written 
		b1 = (a1 && a2);
		
	Number 32
		[]it should be written 
		(b1 == b2) && (a1 <= a2);
	
	Number 33
		[]if that is the statment then if it prints the output "al equals 4", it makes no sense because that is given if the if
		the if statement is true, so the better output would be System.out.println(Correct)
	
	Number 34
		[]for the if statement, the argument must be in ()
	
	Number 35
		[]for the if statement, the argument must be in () not {}
	
	Number 36
		[]the else statement must have an argument, and it should be else(b1 != true)
		[]also the last println does not make any sense, it should just be ("a1 is < 100");
	Number 37
		[]there is nothing wrong with this code
	
	Number 38
		[] there is nothing wrong with this code