/*
	Number 5
		Enter an int > 3
		Hello
		Enter an int > 5
		Hello
		Enter an int > -1
	Number 6
		Hello
		Enter an int > 3
		Hello
		Enter an int > 5
		Hello
		Enter an int > -1
	Number 7 
		Enter an int > 3
		Enter an int > 5
		Hello
		Enter an int > -1
		Hello
	Number 8
		Sum=7
		i=18
		Sum=25
		i=19
		Sum=44
		i=20
	Number 30
		[] this is an ifinite loop because i=0 will always be less than 3
	Number 32
		[] this is off by one, for hello to print hello 3 times your must have i<4 in your while statement
	Number 33
		[] this causes an infinite loop, to fix this you would change so i=11 and chaange i++ to i--
*/

