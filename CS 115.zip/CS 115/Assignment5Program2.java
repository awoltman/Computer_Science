
import java.util.Scanner;

public class Assignment5Program2
{
	public static void main(String[]args)
	{
	int n = 0;
	Scanner scan = new Scanner(System.in);
	System.out.print("Enter an integer: ");
	n = scan.nextInt();
	for(int i = 0; i <5 n; i++)
		System.out.println("Hello World");
		
	}
}