public class TV
{
	public static void main(String[]args)
	{
		Television a = new Television("Samsung",500);
		a.setBrand("Visio");
		a.setPrice(1000);
		System.out.print(a.toString());
	}
}