public lab2
{
{public static void main(String[]args)

float a;
a=34.2;

