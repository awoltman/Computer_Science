public class random
{
public static void main(String[]args)
{
boolean b2 = false;
int a1 = 4;
int a2 = 20;
if (b2)
	System.out.println("b2 is true");
else if(a1 <= 10 || a2 > 50)
{
	System.out.println("a1<= 10 or");
	System.out.println("a2 > 50");
}
else
	System.out.println("non of the above");
}
}