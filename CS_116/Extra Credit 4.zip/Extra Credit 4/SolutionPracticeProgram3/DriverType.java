//George Koutsogiannakis
package Driverclass1.Driverclass2;
public enum DriverType{Adult_Male_Driver, Adult_Female_Driver, Teenager_Male_Driver, Teenager_Female_Driver, None};
