package andrew.woltman;
public enum MaterialCategories { AluminumBased,Metal,Cellulose,Glass};