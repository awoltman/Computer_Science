public interface INT2
{
	 
	 public double calculateVolume();
}
