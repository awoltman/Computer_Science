import java.util.Vector;
public interface INT3
{
	 
	 public Vector secretData();
}