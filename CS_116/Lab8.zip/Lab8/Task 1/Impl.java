import java.util.Vector;
public class Impl extends Customers implements INT3
{
	

	

	public Vector secretData()
	{
		Vector v1=customerData();
		return v1;
	}
}
