import java.util.*;
import java.io.*;

public interface Basics
{
	 
	public abstract void distance();
    public abstract void magnitude();
    public abstract void charge();
}
