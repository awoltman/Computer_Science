//George Koutsogiannakis
//package ClientClass.ServiceClasses;
public enum BookType{FICTION,NONFICTION,RELIGION,HISTORY,SHORTSTORIES,NONE};
