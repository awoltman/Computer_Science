package main.service.enums;
public enum CarType {Type1,Type2,Type3,Type4};