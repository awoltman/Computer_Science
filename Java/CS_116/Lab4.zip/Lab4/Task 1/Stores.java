package main.service.enums;
public enum Stores {ID1,ID2,ID3,ID4,ID5};