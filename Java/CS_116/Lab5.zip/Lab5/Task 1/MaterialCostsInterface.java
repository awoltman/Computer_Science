package Client.Services.Enums.Help;

public interface MaterialCostsInterface
{
	public double getMaterialExpenses();
}