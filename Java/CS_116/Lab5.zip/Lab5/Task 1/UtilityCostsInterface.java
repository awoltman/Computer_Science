package Client.Services.Enums.Help;

public interface UtilityCostsInterface
{
	public double getUtilityExpenses();
}