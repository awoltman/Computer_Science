package Client.Services.Enums.Help;

public interface ExpenseInterface
{
	public double getRecurringExpenses();
	
}